# TKINTER-Space-Invaders
Instituto Tecnologico de Costa Rica

Space invaders - Harold Espinoza Matarrita/Fabricio Mena Mejia

Para este juego se utilizo la version de python 3.7.2
En caso de querer activar los cheats se deberan introducir los siguientes codigos
"pra pra pra"
"on fire"
"hongo verde"
Simplemente basta con teclearlos una vez iniciado el juego, en caso de equivocarse en una letra
se puede presionar la "q" para resetar el cheat, ademas se recomienda presionarla antes de escribir un
codigo para asegurase de que el programa lo acepte
